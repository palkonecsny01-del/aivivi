---
name: ✨ Feature / Task
about: Új funkció vagy fejlesztési feladat
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

## Leírás
<!-- Mit kell megvalósítani? -->

## Motiváció
<!-- Miért szükséges ez a fejlesztés? -->

## Elfogadási kritérium
<!-- Mikor tekinthető késznek? -->
- [ ] 
- [ ] 

## Sprint
- [ ] Sprint 1 – UX
- [ ] Sprint 2 – System Prompt
- [ ] Sprint 3 – Skills
- [ ] Sprint 4 – Tesztelés
- [ ] Sprint 5 – Extra

## Típus
- [ ] UX
- [ ] Core
- [ ] Refactor
- [ ] Feature
- [ ] Docs
- [ ] Test
