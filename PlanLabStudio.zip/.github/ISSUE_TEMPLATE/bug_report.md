---
name: 🐛 Bug report
about: Hibajelentés a AIVIVI rendszerhez
title: '[BUG] '
labels: bug
assignees: ''
---

## Leírás
<!-- Röviden írd le a hibát -->

## Reprodukálás lépései
1. 
2. 
3. 

## Várt viselkedés
<!-- Mi kellett volna hogy történjen? -->

## Aktuális viselkedés
<!-- Mi történt helyette? -->

## Sprint
<!-- Melyik sprinthez tartozik? -->
- [ ] Sprint 0 – Alap stabilizáció
- [ ] Sprint 1 – UX
- [ ] Sprint 2 – System Prompt
- [ ] Sprint 3 – Skills
- [ ] Sprint 4 – Tesztelés

## Prioritás
- [ ] High
- [ ] Medium
- [ ] Low
